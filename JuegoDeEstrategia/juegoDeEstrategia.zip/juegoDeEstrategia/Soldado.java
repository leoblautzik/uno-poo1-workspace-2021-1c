package juegoDeEstrategia;
/*
Reglas del juego:
Los Soldados pueden atacar cuerpo a cuerpo a otros Soldados
si tienen suficiente energía. 
Cada ataque consume 10 puntos de energía, y 
comienzan con 100. Restauran energía si reciben la poción de agua. 
Comienzan con 200 puntos de salud e 
infringen un daño de 10 puntos de salud al adversario.
Ninguna unidad muerta puede atacar, por supuesto.

*/

public class Soldado {

	int energia = 100;
	int salud = 200;
	private static final int DANIO_INFINGIDO = 10;
	private static final int ENERGIA_CONSUMIDA_POR_ATAQUE = 10;

	public boolean puedeAtacar() {
		return tieneSuficienteEnergia() && !estaMuerto();
	}

	public boolean estaMuerto() {
		return this.getSalud() <= 0;
	}

	public boolean tieneSuficienteEnergia() {

		return this.getEnergia() >= ENERGIA_CONSUMIDA_POR_ATAQUE;
		
	}

	public void atacar(Soldado adversario) {
		if (this.puedeAtacar()) {
		
			this.restarEnergia();
			adversario.sufrirDanio();
		
		}
				
	}

	private void sufrirDanio() {
		this.salud -= DANIO_INFINGIDO;

	}

	private void restarEnergia() {
		this.energia -= ENERGIA_CONSUMIDA_POR_ATAQUE;

	}

	public int getEnergia() {
		return this.energia;
	}

	public int getSalud() {
		return salud;
	}
	
	public void beberAgua() {
		this.energia = 100;
	}

}
